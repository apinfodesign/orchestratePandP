# Pride-And-Prejudice
Contents of _Pride And Prejudice_ by Jane Austen

# LICENSE

_Pride and Prejudice_ itself is in the public domain. These contents were drawn from an epub file distributed by Project Gutenberg; the html files in the git history are subject to the [Gutenberg License](http://www.gutenberg.org/wiki/Gutenberg:The_Project_Gutenberg_License).
